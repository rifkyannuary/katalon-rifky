<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Pelunasan FPH</name>
   <tag></tag>
   <elementGuidId>028cbda8-6c6e-445c-98d4-62ceca95da66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_Menu1n39 > td > table.ctl00_Menu1_6 > tbody > tr > td > a.ctl00_Menu1_1.ctl00_Menu1_5</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='ctl00_Menu1n39']/td/table/tbody/tr/td/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d61e8a50-8842-4571-8014-942dfe52dac7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ctl00_Menu1_1 ctl00_Menu1_5</value>
      <webElementGuid>d178fb43-bdc9-431b-8706-eb2b85a80b19</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>fFPHInstallment.aspx</value>
      <webElementGuid>b394f943-2bb9-48b4-83c6-ba7a432312cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Pelunasan FPH</value>
      <webElementGuid>82deb293-a777-4b1c-b4c5-8ba7a00a5de6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_Menu1n39&quot;)/td[1]/table[@class=&quot;ctl00_Menu1_6&quot;]/tbody[1]/tr[1]/td[1]/a[@class=&quot;ctl00_Menu1_1 ctl00_Menu1_5&quot;]</value>
      <webElementGuid>b2b9ea63-42fb-4f64-92e4-512fb8534774</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='ctl00_Menu1n39']/td/table/tbody/tr/td/a</value>
      <webElementGuid>3e49c367-0ab8-46f2-83da-f55619c997cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Pelunasan FPH')]</value>
      <webElementGuid>026773bb-cdae-43ee-9101-7baef8d2deeb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report FPH'])[1]/following::a[1]</value>
      <webElementGuid>10859b73-63ed-464e-b5b1-8f4bfc5f5841</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cabang FPH'])[1]/following::a[2]</value>
      <webElementGuid>5a48a183-3da6-4a09-ab9b-c8642646d535</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Asset Selling Request'])[1]/preceding::a[1]</value>
      <webElementGuid>2216e802-02fe-4810-8474-774d2f7f5683</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Asset Selling View'])[1]/preceding::a[2]</value>
      <webElementGuid>7fe9069c-7ed9-4fae-afc2-8160f2b651ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Pelunasan FPH']/parent::*</value>
      <webElementGuid>693afb91-bba3-4de0-94fb-1068d0263b65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'fFPHInstallment.aspx')]</value>
      <webElementGuid>0f622c43-4067-4ed1-8436-6488f9d5e43a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/table/tbody/tr[3]/td/table/tbody/tr/td/a</value>
      <webElementGuid>e3b240ce-7272-430f-a5af-6d9e825a8462</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'fFPHInstallment.aspx' and (text() = 'Pelunasan FPH' or . = 'Pelunasan FPH')]</value>
      <webElementGuid>c38c6250-dc24-466e-96cb-1ed25b6a845e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
