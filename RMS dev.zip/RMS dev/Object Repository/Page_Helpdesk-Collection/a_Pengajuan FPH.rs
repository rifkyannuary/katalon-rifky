<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Pengajuan FPH</name>
   <tag></tag>
   <elementGuidId>9e7596fb-ddf3-4823-99e2-2c6b90e6f622</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_Menu1n36 > td > table.ctl00_Menu1_6 > tbody > tr > td > a.ctl00_Menu1_1.ctl00_Menu1_5</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='ctl00_Menu1n36']/td/table/tbody/tr/td/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>537043d5-5bc8-4745-bbdc-0c0127419b05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ctl00_Menu1_1 ctl00_Menu1_5</value>
      <webElementGuid>8b60066e-27ed-469e-b8e2-160143ab143a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>javascript:__doPostBack('ctl00$Menu1','HelpDesk Collection\\Pengajuan FPH')</value>
      <webElementGuid>e56c964e-50be-4f70-8b85-dec55d452624</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Pengajuan FPH</value>
      <webElementGuid>71706007-522a-4c7d-a060-751c55a6ba8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_Menu1n36&quot;)/td[1]/table[@class=&quot;ctl00_Menu1_6&quot;]/tbody[1]/tr[1]/td[1]/a[@class=&quot;ctl00_Menu1_1 ctl00_Menu1_5&quot;]</value>
      <webElementGuid>90126b07-197b-4dd1-973f-13daa868bf47</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='ctl00_Menu1n36']/td/table/tbody/tr/td/a</value>
      <webElementGuid>297c45d8-83dc-4b0b-a56d-2cb3caeb2c68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Pengajuan FPH')]</value>
      <webElementGuid>b39328e0-e99d-4851-a112-cf5ebd50a0f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Surat Kuasa WO'])[1]/following::a[1]</value>
      <webElementGuid>3ee4c8a6-804d-485a-9aeb-f05ab3db873f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setting Upload TAH'])[1]/following::a[2]</value>
      <webElementGuid>61694778-eeae-45d7-bac2-3c1073eed20e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cabang FPH'])[1]/preceding::a[1]</value>
      <webElementGuid>29222c53-d2d1-426f-a28e-abb1634928bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report FPH'])[1]/preceding::a[2]</value>
      <webElementGuid>314f327f-ac7f-4098-b62f-89a0ae12b206</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Pengajuan FPH']/parent::*</value>
      <webElementGuid>39970677-b460-417b-bdf6-e9c20105ef4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, &quot;javascript:__doPostBack('ctl00$Menu1','HelpDesk Collection\\Pengajuan FPH')&quot;)]</value>
      <webElementGuid>abec6968-2b04-4a35-985d-ebf05e82efef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/table/tbody/tr/td/table/tbody/tr/td/a</value>
      <webElementGuid>c05495b3-80b7-458b-892b-1f36d44aa975</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = concat(&quot;javascript:__doPostBack(&quot; , &quot;'&quot; , &quot;ctl00$Menu1&quot; , &quot;'&quot; , &quot;,&quot; , &quot;'&quot; , &quot;HelpDesk Collection\\Pengajuan FPH&quot; , &quot;'&quot; , &quot;)&quot;) and (text() = 'Pengajuan FPH' or . = 'Pengajuan FPH')]</value>
      <webElementGuid>bb82079a-17d8-4879-8e2d-7cb114966b2e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
