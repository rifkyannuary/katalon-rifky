<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_SKP (Surat Kuasa Penarikan)</name>
   <tag></tag>
   <elementGuidId>7add28f6-a96a-4756-a939-7800812a85b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_cmbYear</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_cmbYear']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>e0472443-13e3-4ad2-b36a-a082c8c80619</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$cmbYear</value>
      <webElementGuid>9eeb351b-c52d-420b-ad78-6e1b7b438112</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_cmbYear</value>
      <webElementGuid>3f4fa7fe-0072-45d0-bc54-e481b1f20af1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	SKP (Surat Kuasa Penarikan)

</value>
      <webElementGuid>b1b91048-cee7-463f-a144-e43efaa7f0fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_cmbYear&quot;)</value>
      <webElementGuid>9b7e4249-fb8d-4704-a75d-2fc578d0b578</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_cmbYear']</value>
      <webElementGuid>991a0eb1-d855-44e8-af45-5e0516820dea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/table/tbody/tr[2]/td[2]/select</value>
      <webElementGuid>509525ba-9f7c-4fb3-b371-194847f8bef5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Type'])[1]/following::select[1]</value>
      <webElementGuid>1c2fcfdc-87db-4448-90d5-0ed5e857d8da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Producktivitas ProfColl'])[1]/following::select[1]</value>
      <webElementGuid>1194d646-9630-4f71-86ec-e3a24688132f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::select[1]</value>
      <webElementGuid>7c385302-56ba-4dcd-a5f7-9000964253be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alt'])[1]/preceding::select[1]</value>
      <webElementGuid>362c10ce-c5f8-4155-b860-a4cfb24d883e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>88cbc248-7995-4062-9ca1-fd77eb677e4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$cmbYear' and @id = 'ctl00_ContentPlaceHolder1_cmbYear' and (text() = '
	SKP (Surat Kuasa Penarikan)

' or . = '
	SKP (Surat Kuasa Penarikan)

')]</value>
      <webElementGuid>3bdf024b-2119-4e02-9a65-70f8d1503a41</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
