<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_report</name>
   <tag></tag>
   <elementGuidId>112aba3a-4b3b-4eaa-a306-b7769335a61e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_cmbReport</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_cmbReport']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>a72d769a-4546-438f-a547-14fcb101826d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$cmbReport</value>
      <webElementGuid>dcfba294-229f-409e-aaf9-0e8ee0a830ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_cmbReport</value>
      <webElementGuid>63589c45-6702-4455-b57f-a6324875e2ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Double PIC

</value>
      <webElementGuid>7c5cd553-d601-40cc-818c-70b2f47425d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_cmbReport&quot;)</value>
      <webElementGuid>9b1774e7-1e80-4774-a0bc-4e8b71ec9e8a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_cmbReport']</value>
      <webElementGuid>a80ce755-d90c-496a-a4fa-1fc62f224cf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/table/tbody/tr[2]/td[2]/select</value>
      <webElementGuid>a7fb44b3-e42d-4fe4-a55e-3db1f6a0f390</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report'])[2]/following::select[1]</value>
      <webElementGuid>89fda52d-ba3a-4384-b52e-8796bd25b4fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mapping Area'])[1]/following::select[1]</value>
      <webElementGuid>8fa57398-8d50-4ffe-b4ee-44f6b5660dc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Collector Type'])[1]/preceding::select[1]</value>
      <webElementGuid>64215497-4306-4602-bbc1-6633ca62e9f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Type'])[1]/preceding::select[2]</value>
      <webElementGuid>958a9122-8667-4a58-975d-9e2583e04aa0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>5c39291b-ed2b-44d7-ae66-4b98d892c5dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$cmbReport' and @id = 'ctl00_ContentPlaceHolder1_cmbReport' and (text() = '
	Double PIC

' or . = '
	Double PIC

')]</value>
      <webElementGuid>bc247e0f-109c-4eab-bccc-7fc2500ae3cf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
