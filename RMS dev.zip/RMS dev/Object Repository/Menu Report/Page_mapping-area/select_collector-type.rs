<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_collector-type</name>
   <tag></tag>
   <elementGuidId>ceb17458-ba8b-49bb-8c67-b9d27bd2e91a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_cmbKriteria</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_cmbKriteria']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>139d7de2-02a6-4752-8229-2365899af731</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$cmbKriteria</value>
      <webElementGuid>5e2958fc-b691-4d31-b91c-c0549077069c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_cmbKriteria</value>
      <webElementGuid>5db90c30-9e80-48d7-b4ec-3354e0bfa4c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Field Collector 1
	Field Collector 2
	Remedial
	Field Collector 3
	Field Collector 4

</value>
      <webElementGuid>382f886f-b739-4129-a8dc-3b33000e0be8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_cmbKriteria&quot;)</value>
      <webElementGuid>5fc3c66e-cc84-44cb-b8ef-a99cd82711d0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_cmbKriteria']</value>
      <webElementGuid>9ec3a7c6-adc1-4209-a156-1404a416e7ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/table/tbody/tr[3]/td[2]/select</value>
      <webElementGuid>eff5422d-a124-41ed-945c-da5ca292d649</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Collector Type'])[1]/following::select[1]</value>
      <webElementGuid>e9888386-adcd-4cc6-aa88-9a5ea802b719</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report'])[2]/following::select[2]</value>
      <webElementGuid>6d4cbb1a-b1fd-4592-bc9b-f7c30d06cf7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Type'])[1]/preceding::select[1]</value>
      <webElementGuid>942e4885-e83b-4bbb-b3bb-2494173945ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::select[2]</value>
      <webElementGuid>ef32f4a3-cbab-41f4-b0fc-5a3145a0064e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td[2]/select</value>
      <webElementGuid>fb9e55a3-fa7f-40e6-9826-9a1ac9bcde11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$cmbKriteria' and @id = 'ctl00_ContentPlaceHolder1_cmbKriteria' and (text() = '
	Field Collector 1
	Field Collector 2
	Remedial
	Field Collector 3
	Field Collector 4

' or . = '
	Field Collector 1
	Field Collector 2
	Remedial
	Field Collector 3
	Field Collector 4

')]</value>
      <webElementGuid>54153874-4ac9-414d-a90a-3e784172c0e7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
