<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Performa Individu</name>
   <tag></tag>
   <elementGuidId>153e3c2d-1d7d-471c-85c3-e4449ecc3041</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_Menu1n14 > td > table.ctl00_Menu1_6 > tbody > tr > td > a.ctl00_Menu1_1.ctl00_Menu1_5</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='ctl00_Menu1n14']/td/table/tbody/tr/td/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>393cf3cb-58fd-47b6-a26e-939bafd03e10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ctl00_Menu1_1 ctl00_Menu1_5</value>
      <webElementGuid>cb5c8d8f-c843-47e9-8eba-b649be2fd0c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>fPerfIndividu.aspx</value>
      <webElementGuid>bd01f5b8-0c13-4361-8755-f6c256895f38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Performa Individu</value>
      <webElementGuid>0ea257be-4ecb-4a39-a5d6-ffb85c884808</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_Menu1n14&quot;)/td[1]/table[@class=&quot;ctl00_Menu1_6&quot;]/tbody[1]/tr[1]/td[1]/a[@class=&quot;ctl00_Menu1_1 ctl00_Menu1_5&quot;]</value>
      <webElementGuid>5a7d79bd-b409-4a42-b97e-0d8f2665d198</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='ctl00_Menu1n14']/td/table/tbody/tr/td/a</value>
      <webElementGuid>96b17660-04d3-4d76-9060-c9f0235fb568</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Performa Individu')]</value>
      <webElementGuid>ec5acc82-854e-4465-9a6a-141c90c8697a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Progress Daily'])[1]/following::a[1]</value>
      <webElementGuid>3a79954a-40ee-40e2-989d-74bc6f6ab666</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Type'])[1]/following::a[2]</value>
      <webElementGuid>23c84052-50da-4b41-bd8a-3d795c6489f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profcoll Productivity'])[1]/preceding::a[1]</value>
      <webElementGuid>f3ace50c-18dd-40e4-8566-05fb69b04d36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mapping Area'])[1]/preceding::a[2]</value>
      <webElementGuid>1b949e47-9881-414d-aec0-021ee5b618ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Performa Individu']/parent::*</value>
      <webElementGuid>1749f142-02a8-4685-90eb-cd141c62a38c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'fPerfIndividu.aspx')]</value>
      <webElementGuid>0982582e-b798-442d-8a4c-aee4bb27cf0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/table/tbody/tr[3]/td/table/tbody/tr/td/a</value>
      <webElementGuid>3e11dd66-48f4-43fe-b5ab-69863de3c083</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'fPerfIndividu.aspx' and (text() = 'Performa Individu' or . = 'Performa Individu')]</value>
      <webElementGuid>5d913f55-29d4-46a3-b7c7-c8412d66120b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
