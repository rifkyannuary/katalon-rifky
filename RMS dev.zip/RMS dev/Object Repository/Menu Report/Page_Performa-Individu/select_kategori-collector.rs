<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_kategori-collector</name>
   <tag></tag>
   <elementGuidId>b3b12403-b222-48e5-a83f-973a3c6eea1d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_cmbKriteria</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_cmbKriteria']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>8db1269c-0aab-4f33-94cc-2612d2bafabf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$cmbKriteria</value>
      <webElementGuid>8ade086e-ff5c-4c23-b82c-e6bbcbd2970a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_cmbKriteria</value>
      <webElementGuid>b7b86c05-8c97-4bb8-8ac7-19e740304418</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Field Collector 1
	Field Collector 2
	Remedial
	Koordinator Field Collector 1
	Koordinator Field Collector 2
	Field Collector 3
	Field Collector 4
	Koordinator Remedial
	Koordinator Field Collector 3

</value>
      <webElementGuid>e3b3d353-74b2-4c3c-b0e0-62b265018836</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_cmbKriteria&quot;)</value>
      <webElementGuid>eeeed38a-ab5d-4750-95af-08915962f12c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_cmbKriteria']</value>
      <webElementGuid>3cf7a257-f1d4-4eaf-9331-4f8d02614ab6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/table/tbody/tr[4]/td/select</value>
      <webElementGuid>cdd6c5f1-f41a-42f8-86c1-e5b6d5951156</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Performa Individu'])[1]/following::select[2]</value>
      <webElementGuid>a07d66c9-edf2-4fd0-bc63-ad255226f050</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::select[1]</value>
      <webElementGuid>c2f75b79-589b-40db-9eec-da282678ee17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alt'])[1]/preceding::select[1]</value>
      <webElementGuid>61aabe3c-03f8-4112-bc5a-368bd5922a13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[4]/td/select</value>
      <webElementGuid>a91cba9f-934b-4e83-9de7-e744ee1201ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$cmbKriteria' and @id = 'ctl00_ContentPlaceHolder1_cmbKriteria' and (text() = '
	Field Collector 1
	Field Collector 2
	Remedial
	Koordinator Field Collector 1
	Koordinator Field Collector 2
	Field Collector 3
	Field Collector 4
	Koordinator Remedial
	Koordinator Field Collector 3

' or . = '
	Field Collector 1
	Field Collector 2
	Remedial
	Koordinator Field Collector 1
	Koordinator Field Collector 2
	Field Collector 3
	Field Collector 4
	Koordinator Remedial
	Koordinator Field Collector 3

')]</value>
      <webElementGuid>653911d0-b87e-470a-a3a4-30e7af93f808</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
