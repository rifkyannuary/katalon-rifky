<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Progress Daily</name>
   <tag></tag>
   <elementGuidId>b9312f33-1d6b-41d7-aa3d-8326656c1164</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_Menu1n13 > td > table.ctl00_Menu1_6 > tbody > tr > td > a.ctl00_Menu1_1.ctl00_Menu1_5</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='ctl00_Menu1n13']/td/table/tbody/tr/td/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4d444fe1-f656-4bb3-ac5c-b7f4f16c7bdb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ctl00_Menu1_1 ctl00_Menu1_5</value>
      <webElementGuid>0d139669-8492-477e-938c-3c4901b4dca2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>fProgressBranch.aspx</value>
      <webElementGuid>8db4a2c0-0e33-4b82-9cb7-d579a8a598b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Progress Daily</value>
      <webElementGuid>c6f35e4d-52ad-4d79-b724-47b746a8c046</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_Menu1n13&quot;)/td[1]/table[@class=&quot;ctl00_Menu1_6&quot;]/tbody[1]/tr[1]/td[1]/a[@class=&quot;ctl00_Menu1_1 ctl00_Menu1_5&quot;]</value>
      <webElementGuid>35c6151a-a9d2-4aff-9dad-9d7abd1b8bfe</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='ctl00_Menu1n13']/td/table/tbody/tr/td/a</value>
      <webElementGuid>897ce267-37c5-4794-98a2-5f84adb516ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Progress Daily')]</value>
      <webElementGuid>039f4da2-c74e-4bb0-a848-1b654e349744</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Type'])[1]/following::a[1]</value>
      <webElementGuid>807b934f-3773-4576-98d9-8b4500f0ac09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assign Collector'])[1]/following::a[2]</value>
      <webElementGuid>94001643-5cf1-4d7f-9fcc-9421c490b5fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Performa Individu'])[1]/preceding::a[1]</value>
      <webElementGuid>ec056c9b-8c95-4595-a661-a0584beb2dd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profcoll Productivity'])[1]/preceding::a[2]</value>
      <webElementGuid>c6387f54-96aa-4804-8c47-6354d3b4331a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Progress Daily']/parent::*</value>
      <webElementGuid>e7bed590-758c-4237-a39d-6baf07b2b0d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'fProgressBranch.aspx')]</value>
      <webElementGuid>4919667e-54e9-463c-857b-9ab6cbbf2f4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/table/tbody/tr[2]/td/table/tbody/tr/td/a</value>
      <webElementGuid>cf1ba214-652a-4cb9-a70e-494ff6105266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'fProgressBranch.aspx' and (text() = 'Progress Daily' or . = 'Progress Daily')]</value>
      <webElementGuid>38246a41-8e87-4a88-b3c5-01668ef518f0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
