<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_region</name>
   <tag></tag>
   <elementGuidId>7a52005c-fee1-4f57-a5dc-46c3d8f23f10</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_dlRegion</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>7e3813fd-f1b6-4d8e-9731-92c9836db446</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$dlRegion</value>
      <webElementGuid>7bc1c798-b085-4268-984e-7761f0898dad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$dlRegion\',\'\')', 0)</value>
      <webElementGuid>2fb98881-e991-46b8-a5b0-92dc5b8ce8f2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_dlRegion</value>
      <webElementGuid>ad8132d7-49da-4a2e-8c86-af93e52c5d55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	--SELECT--
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR

</value>
      <webElementGuid>9608af90-f67c-4cb3-b823-c0f8049edf74</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_dlRegion&quot;)</value>
      <webElementGuid>f6aca4d4-c34c-49e2-8b37-251d8c3344d3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      <webElementGuid>0aabdf76-d754-4778-a9e3-f947689282cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[5]/td/table/tbody/tr[3]/td[2]/select</value>
      <webElementGuid>1f1c9883-c1e5-4454-8635-cd407b29b78d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Region'])[1]/following::select[1]</value>
      <webElementGuid>fa5c9a13-404b-4508-af9d-8e752dab418f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Produk'])[1]/following::select[2]</value>
      <webElementGuid>3f0dbd78-72db-4a2e-9d85-8bebdaeb5204</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Branch'])[1]/preceding::select[1]</value>
      <webElementGuid>14e003ef-821d-4a2b-ad91-f0792b4eab69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pos'])[1]/preceding::select[2]</value>
      <webElementGuid>5d2b1de5-d036-4ea9-a7c6-51579709dd59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td[2]/select</value>
      <webElementGuid>682f0163-7ac4-44d1-98b8-c83942baeed7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$dlRegion' and @id = 'ctl00_ContentPlaceHolder1_dlRegion' and (text() = '
	--SELECT--
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR

' or . = '
	--SELECT--
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR

')]</value>
      <webElementGuid>2acc9343-7c4d-4fc2-ab7d-124b2442a241</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
