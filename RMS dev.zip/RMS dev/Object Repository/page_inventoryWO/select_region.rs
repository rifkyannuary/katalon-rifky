<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_region</name>
   <tag></tag>
   <elementGuidId>2173f94a-7baf-43bc-8277-69db3ee79028</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_dlRegion</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>43fb2212-4339-4465-b834-6cd6a02ec93a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$dlRegion</value>
      <webElementGuid>39142461-f4f7-4d3a-91da-c797345f5ad4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_dlRegion</value>
      <webElementGuid>55229149-c459-4a91-a742-7b0f68570b99</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	ALL
	JABODETABEK
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM

</value>
      <webElementGuid>e96ac7fd-fd43-49fc-9931-0b7347c1946d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_dlRegion&quot;)</value>
      <webElementGuid>c60160a4-39a0-4a7a-aa97-28bff72efbb8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      <webElementGuid>df27afc7-6d64-4892-922c-6cc2d85c42f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/div/table/tbody/tr[2]/td[2]/select</value>
      <webElementGuid>9841de07-928e-42ca-8e42-24182c0db972</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Region'])[1]/following::select[1]</value>
      <webElementGuid>45949eca-7982-4997-868f-54c58663fd2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INVENTORY WO'])[1]/following::select[1]</value>
      <webElementGuid>8df2cc20-3ba1-4da2-98ed-8e859806c643</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Product'])[1]/preceding::select[1]</value>
      <webElementGuid>f877c4cf-32f7-4c72-b3f3-1a5e18ba145f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Inventory Date'])[1]/preceding::select[2]</value>
      <webElementGuid>02776e90-79b7-4596-a0af-a4fabc5288a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>499e87ad-d749-4f70-b516-a9c937d5cd42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$dlRegion' and @id = 'ctl00_ContentPlaceHolder1_dlRegion' and (text() = '
	ALL
	JABODETABEK
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM

' or . = '
	ALL
	JABODETABEK
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM

')]</value>
      <webElementGuid>01345317-8cde-4b83-9297-feb4a229a636</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
