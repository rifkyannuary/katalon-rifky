<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Report Inventory WO</name>
   <tag></tag>
   <elementGuidId>a7d9e514-0878-417d-9e29-b95fcbcaf958</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='ctl00_Menu1n32']/td/table/tbody/tr/td/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#ctl00_Menu1n32 > td > table.ctl00_Menu1_6 > tbody > tr > td > a.ctl00_Menu1_1.ctl00_Menu1_5</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>908079a8-a4ca-4dbf-a3ac-9b34c60b5448</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ctl00_Menu1_1 ctl00_Menu1_5</value>
      <webElementGuid>4cb3e98c-3e84-4fa5-8dee-b614fbf50be7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>fInventoryWO.aspx</value>
      <webElementGuid>46b718f1-539d-4654-908d-98b3f0298d7e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Report Inventory WO</value>
      <webElementGuid>d65512b1-f9c1-4011-9be4-9762f5f25e68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_Menu1n32&quot;)/td[1]/table[@class=&quot;ctl00_Menu1_6&quot;]/tbody[1]/tr[1]/td[1]/a[@class=&quot;ctl00_Menu1_1 ctl00_Menu1_5&quot;]</value>
      <webElementGuid>ed5ad789-8caa-499e-9790-95ef1452f9b4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='ctl00_Menu1n32']/td/table/tbody/tr/td/a</value>
      <webElementGuid>e0e4fb44-e0a4-4920-a52a-41fdd8de4fc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Report Inventory WO')]</value>
      <webElementGuid>ca299240-3aed-4de1-b7e9-c3ffec889a9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Performance WO'])[1]/following::a[1]</value>
      <webElementGuid>6ac9e16e-7c2c-42c8-8688-0d90be323e26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard WO'])[1]/following::a[2]</value>
      <webElementGuid>1cd7b163-8548-42ec-a873-059e44d04412</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Update Repossess WO'])[1]/preceding::a[1]</value>
      <webElementGuid>17ad08ef-005a-4e7c-a190-e05ffcb9f58f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setting Upload TAH'])[1]/preceding::a[2]</value>
      <webElementGuid>6525bbed-a210-4ded-9e62-54d16438c913</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Report Inventory WO']/parent::*</value>
      <webElementGuid>40bec527-4fbb-4830-bc72-ce2fd28044d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'fInventoryWO.aspx')]</value>
      <webElementGuid>4cf35763-81ae-4bb6-9adf-1d7fb2aa08b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[11]/td/table/tbody/tr/td/a</value>
      <webElementGuid>c94afd09-ef14-463c-828f-a9e8cbcc64f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'fInventoryWO.aspx' and (text() = 'Report Inventory WO' or . = 'Report Inventory WO')]</value>
      <webElementGuid>3cdb212b-94d4-4b16-b520-6bca1b6d5064</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
