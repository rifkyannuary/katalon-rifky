<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_region</name>
   <tag></tag>
   <elementGuidId>cb04575d-9a95-456c-b3e0-93290afb8dac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_cmbRegion</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_cmbRegion']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>7570033f-4a04-4e18-b68b-f4b8b9093754</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$cmbRegion</value>
      <webElementGuid>e0697171-3445-4811-b1cd-672932887a9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$cmbRegion\',\'\')', 0)</value>
      <webElementGuid>ca34b133-6242-4b95-8165-34e26278a356</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_cmbRegion</value>
      <webElementGuid>6f799c62-a801-400d-bdd7-ea36d2f4d401</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Select One
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR
	ALL

</value>
      <webElementGuid>b40b0f7f-e659-4136-9a04-62b540844fa6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_cmbRegion&quot;)</value>
      <webElementGuid>6bb0db07-123f-4985-a588-581ce0712381</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_cmbRegion']</value>
      <webElementGuid>0e9fbbb5-b63e-4c6b-87d4-8eb155ed7610</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/table/tbody/tr[8]/td[3]/select</value>
      <webElementGuid>eb35c388-1ba8-4d90-b33f-5b0dd1f02d93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=':'])[6]/following::select[1]</value>
      <webElementGuid>f7354c73-9f18-472d-b927-7362b302428c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Region'])[1]/following::select[1]</value>
      <webElementGuid>9d21e1f3-f800-47b6-870a-54fe5b9b8e9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*)'])[6]/preceding::select[1]</value>
      <webElementGuid>887013ab-f4cd-4781-9257-8c00d5345989</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Branch'])[1]/preceding::select[1]</value>
      <webElementGuid>92e664ce-35ee-4a05-ae55-2b3dfe034c2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[8]/td[3]/select</value>
      <webElementGuid>e2b169e1-696f-493e-b0ea-a46eba732c75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$cmbRegion' and @id = 'ctl00_ContentPlaceHolder1_cmbRegion' and (text() = '
	Select One
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR
	ALL

' or . = '
	Select One
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR
	ALL

')]</value>
      <webElementGuid>4e2cdbe0-67a8-4f64-8502-7db7c0abecdf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
