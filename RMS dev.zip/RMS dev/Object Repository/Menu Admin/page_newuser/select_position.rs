<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_position</name>
   <tag></tag>
   <elementGuidId>89a0c038-d098-4ad8-88c5-b0be4d6c32a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_cmbPosition</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_cmbPosition']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>9cc88f2f-cb57-4cf9-b60a-92624aabe9d0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$cmbPosition</value>
      <webElementGuid>bb6de881-e7f8-4ebc-97e6-3b5a76011a0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_cmbPosition</value>
      <webElementGuid>975a4716-09ad-47a0-b6ca-aeae48734dd8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Select One
	Administrator
	Regional Manager KMB
	Regional Manager WG
	Regional Manager KMOB
	Area Collection Manager KMB
	Area Collection Manager WG
	Area Collection Manager KMOB
	Branch Manager KMB
	Branch Manager WG
	Branch Manager KMOB
	KAPOS KMB
	KAPOS WG
	KAPOS KMOB
	HEAD COLLECTION KMB
	HEAD COLLECTION WG
	HEAD COLLECTION KMOB
	KOORDINATOR FC KMB
	KOORDINATOR FC WG
	KOORDINATOR FC  KMOB
	HEAD REMEDIAL KMB
	HEAD REMEDIAL WG
	HEAD REMEDIAL KMOB
	KOORDINATOR REMEDIAL KMB
	KOORDINATOR REMEDIAL WG
	GAD
	CREDIT ANALYST WG
	CREDIT ANALYST KMB
	CREDIT ANALYST KMOB
	P G
	DEVELOPER
	OPERATION
	Branch Manager Multiguna
	REGIONAL MANAGER KMM
	Area Collection Manager KMM
	Head Collection KMM
	Kapos KMM
	KOORDINATOR FC KMM
	KOORDINATOR REMEDIAL KMM
	HEAD REMEDIAL KMM
	REGION WG JABO
	USER CONTROL
	ARCO
	EXTERNAL
	KOORDINATOR REMEDIAL KMOB
	DESK COLLECTION
	CLUSTER COLLECTION MANAGER WG
	CLUSTER COLLECTION MANAGER KMB
	CLUSTER COLLECTION MANAGER KMOB
	CLUSTER COLLECTION MANAGER KMM
	Loan Recovery Coordinator
	Loan Recovery Head
	Marketing WG
	Admin HO
	Tim Admin HO

</value>
      <webElementGuid>da0d24db-842b-45b1-8c70-d887fe98f795</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_cmbPosition&quot;)</value>
      <webElementGuid>b7c49dbc-247a-49d2-b37e-8d7d7a362e37</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_cmbPosition']</value>
      <webElementGuid>5cd2bc54-939a-49a9-acc5-66d98d2cd43c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/table/tbody/tr[7]/td[3]/select</value>
      <webElementGuid>ec015eb3-98a9-4490-8de8-8e41131815b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=':'])[5]/following::select[1]</value>
      <webElementGuid>bb98f74d-8163-4ebd-ab57-1da70e979603</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Position'])[1]/following::select[1]</value>
      <webElementGuid>dbdce2f3-5b05-4f31-9688-181899872662</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*)'])[5]/preceding::select[1]</value>
      <webElementGuid>69203f16-abf2-4f40-bf8d-c28c95cda106</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Region'])[1]/preceding::select[1]</value>
      <webElementGuid>53d09379-539e-4e5f-905a-451d64146020</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>5855db82-6953-4400-90a5-7ce6e6140a67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$cmbPosition' and @id = 'ctl00_ContentPlaceHolder1_cmbPosition' and (text() = '
	Select One
	Administrator
	Regional Manager KMB
	Regional Manager WG
	Regional Manager KMOB
	Area Collection Manager KMB
	Area Collection Manager WG
	Area Collection Manager KMOB
	Branch Manager KMB
	Branch Manager WG
	Branch Manager KMOB
	KAPOS KMB
	KAPOS WG
	KAPOS KMOB
	HEAD COLLECTION KMB
	HEAD COLLECTION WG
	HEAD COLLECTION KMOB
	KOORDINATOR FC KMB
	KOORDINATOR FC WG
	KOORDINATOR FC  KMOB
	HEAD REMEDIAL KMB
	HEAD REMEDIAL WG
	HEAD REMEDIAL KMOB
	KOORDINATOR REMEDIAL KMB
	KOORDINATOR REMEDIAL WG
	GAD
	CREDIT ANALYST WG
	CREDIT ANALYST KMB
	CREDIT ANALYST KMOB
	P G
	DEVELOPER
	OPERATION
	Branch Manager Multiguna
	REGIONAL MANAGER KMM
	Area Collection Manager KMM
	Head Collection KMM
	Kapos KMM
	KOORDINATOR FC KMM
	KOORDINATOR REMEDIAL KMM
	HEAD REMEDIAL KMM
	REGION WG JABO
	USER CONTROL
	ARCO
	EXTERNAL
	KOORDINATOR REMEDIAL KMOB
	DESK COLLECTION
	CLUSTER COLLECTION MANAGER WG
	CLUSTER COLLECTION MANAGER KMB
	CLUSTER COLLECTION MANAGER KMOB
	CLUSTER COLLECTION MANAGER KMM
	Loan Recovery Coordinator
	Loan Recovery Head
	Marketing WG
	Admin HO
	Tim Admin HO

' or . = '
	Select One
	Administrator
	Regional Manager KMB
	Regional Manager WG
	Regional Manager KMOB
	Area Collection Manager KMB
	Area Collection Manager WG
	Area Collection Manager KMOB
	Branch Manager KMB
	Branch Manager WG
	Branch Manager KMOB
	KAPOS KMB
	KAPOS WG
	KAPOS KMOB
	HEAD COLLECTION KMB
	HEAD COLLECTION WG
	HEAD COLLECTION KMOB
	KOORDINATOR FC KMB
	KOORDINATOR FC WG
	KOORDINATOR FC  KMOB
	HEAD REMEDIAL KMB
	HEAD REMEDIAL WG
	HEAD REMEDIAL KMOB
	KOORDINATOR REMEDIAL KMB
	KOORDINATOR REMEDIAL WG
	GAD
	CREDIT ANALYST WG
	CREDIT ANALYST KMB
	CREDIT ANALYST KMOB
	P G
	DEVELOPER
	OPERATION
	Branch Manager Multiguna
	REGIONAL MANAGER KMM
	Area Collection Manager KMM
	Head Collection KMM
	Kapos KMM
	KOORDINATOR FC KMM
	KOORDINATOR REMEDIAL KMM
	HEAD REMEDIAL KMM
	REGION WG JABO
	USER CONTROL
	ARCO
	EXTERNAL
	KOORDINATOR REMEDIAL KMOB
	DESK COLLECTION
	CLUSTER COLLECTION MANAGER WG
	CLUSTER COLLECTION MANAGER KMB
	CLUSTER COLLECTION MANAGER KMOB
	CLUSTER COLLECTION MANAGER KMM
	Loan Recovery Coordinator
	Loan Recovery Head
	Marketing WG
	Admin HO
	Tim Admin HO

')]</value>
      <webElementGuid>94f7c79c-fc10-459e-92c8-a194c7493ac4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
