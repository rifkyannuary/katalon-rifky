<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Update Status WO</name>
   <tag></tag>
   <elementGuidId>eda76265-7e40-463f-b20e-594526bb86b0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_Menu1n27 > td > table.ctl00_Menu1_6 > tbody > tr > td > a.ctl00_Menu1_1.ctl00_Menu1_5</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='ctl00_Menu1n27']/td/table/tbody/tr/td/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d978b10d-a405-4995-b9fd-f38d7e446b42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ctl00_Menu1_1 ctl00_Menu1_5</value>
      <webElementGuid>15b36f1e-81de-4478-a3d8-06d642da3603</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>WOProcessAdm.aspx</value>
      <webElementGuid>3f2d4477-64f7-49f4-9c22-4ad56a7b6e7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Update Status WO</value>
      <webElementGuid>9b40f563-9f9f-442d-a4de-8aabcd6ab5e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_Menu1n27&quot;)/td[1]/table[@class=&quot;ctl00_Menu1_6&quot;]/tbody[1]/tr[1]/td[1]/a[@class=&quot;ctl00_Menu1_1 ctl00_Menu1_5&quot;]</value>
      <webElementGuid>a8f9196e-07fd-47ba-b9cd-21351ca8e12e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='ctl00_Menu1n27']/td/table/tbody/tr/td/a</value>
      <webElementGuid>d1b4a263-ce3f-4095-9350-3ae788526577</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Update Status WO')]</value>
      <webElementGuid>db2a3bcc-c749-43a4-a1f2-9ed5fe0ba5ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Role Menu'])[1]/following::a[1]</value>
      <webElementGuid>8c3bea07-c87c-4efd-b3da-6e589268ba6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Collector List'])[1]/following::a[2]</value>
      <webElementGuid>cb5555f4-0c1b-4b52-8f57-a73f7f43e821</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Message'])[1]/preceding::a[1]</value>
      <webElementGuid>5a09aa1c-3600-45f5-9259-33627ed6ea7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload Status WO'])[1]/preceding::a[2]</value>
      <webElementGuid>f588a034-5b53-4b32-8b86-a0bc517884a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Update Status WO']/parent::*</value>
      <webElementGuid>8b1499cf-bb96-4bdf-8565-7835d7e3ecb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'WOProcessAdm.aspx')]</value>
      <webElementGuid>3fa3414c-aba8-4fc8-98cf-de5df66c66a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/table/tbody/tr[6]/td/table/tbody/tr/td/a</value>
      <webElementGuid>bc756fa3-7364-4212-802c-32e67371e4ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'WOProcessAdm.aspx' and (text() = 'Update Status WO' or . = 'Update Status WO')]</value>
      <webElementGuid>fcf66174-faf4-413a-8fa0-c457772bd72e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
