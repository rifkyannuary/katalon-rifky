<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_region</name>
   <tag></tag>
   <elementGuidId>3fd159a0-bad3-479f-9aac-8f95234ed6d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_dlRegion</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>1b1dc5ec-0a74-4df9-9291-d80fa97f43a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$dlRegion</value>
      <webElementGuid>0ebee37a-d27b-48c8-8878-a357f7eea52a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_dlRegion</value>
      <webElementGuid>5d393107-cc68-4369-b989-dff372a9f03a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>460dc7bf-9bc1-491e-b8ff-700db2c8a895</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	JABAR 1
	JABAR 2
	JAKARTA RAYA
	JATENGTIM
	KALIMANTAN
	SULAWESI-INTIM
	SUMATERA
	ALL

</value>
      <webElementGuid>1aeaedf6-7c94-49ce-b9ab-d113d93dabd0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_dlRegion&quot;)</value>
      <webElementGuid>ff0f7f6c-76c0-4573-b632-b5b9092c87d0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      <webElementGuid>eedb2021-555e-45b4-ac1d-2a55db43328e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/div/table/tbody/tr[2]/td[2]/select</value>
      <webElementGuid>741269c1-43b9-4a55-a8e2-c2a5c1c3c03b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Region'])[1]/following::select[1]</value>
      <webElementGuid>ff6d247b-c833-4e5e-8d30-e7c4ceff41a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard WO'])[2]/following::select[1]</value>
      <webElementGuid>2c87486b-2ff1-4c4e-93cb-2a0635368ef8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Product'])[1]/preceding::select[1]</value>
      <webElementGuid>b74f97b8-0af9-42ab-b2af-a3dc53679d0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Periode'])[1]/preceding::select[2]</value>
      <webElementGuid>9c3a7bab-8445-4a29-9290-ab02ff42c7e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>d391f517-3b07-4e52-9ccf-b89515ed4c81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$dlRegion' and @id = 'ctl00_ContentPlaceHolder1_dlRegion' and (text() = '
	JABAR 1
	JABAR 2
	JAKARTA RAYA
	JATENGTIM
	KALIMANTAN
	SULAWESI-INTIM
	SUMATERA
	ALL

' or . = '
	JABAR 1
	JABAR 2
	JAKARTA RAYA
	JATENGTIM
	KALIMANTAN
	SULAWESI-INTIM
	SUMATERA
	ALL

')]</value>
      <webElementGuid>33fabc14-a646-4732-9b56-29dd02cfe93a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
