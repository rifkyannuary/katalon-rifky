<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_searchby</name>
   <tag></tag>
   <elementGuidId>9b72954a-91de-41a3-946d-1eb6d4ff0c0f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_cmbSearch</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_cmbSearch']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>36a57017-c5cf-48fd-a1ba-0588af635043</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$cmbSearch</value>
      <webElementGuid>ecee8d45-1ab2-4f72-9d10-d88944e5477c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_cmbSearch</value>
      <webElementGuid>af9d3939-efc3-4ae9-b4e5-e823b41db601</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	CollectorID
	Collector Name
	Collector Type

</value>
      <webElementGuid>d318c7bf-2e28-40c7-b9e5-e0c345bcc0fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_cmbSearch&quot;)</value>
      <webElementGuid>351e67e5-0c31-4323-9a6c-c59fbc4059d1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_cmbSearch']</value>
      <webElementGuid>734c401e-5dfc-4874-bded-8fb0579e132c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/table/tbody/tr[2]/td/select</value>
      <webElementGuid>9209f5b4-c1f0-4092-bd61-fe7d6c0d6c7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search By'])[1]/following::select[1]</value>
      <webElementGuid>c44d1b5b-7207-4ab4-b2d0-221d968d2140</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Collector List'])[2]/following::select[1]</value>
      <webElementGuid>97c5f0ba-3b75-4e81-aecc-edc28e3ebef9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CollectorID'])[2]/preceding::select[1]</value>
      <webElementGuid>71067660-fcb9-43ef-9488-2ea48d9ea33e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Collector Name'])[2]/preceding::select[1]</value>
      <webElementGuid>927f9ba5-c184-435f-b211-0fbe56b7e291</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>f7c552ce-57c4-47ee-ab9c-ab91f524a142</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$cmbSearch' and @id = 'ctl00_ContentPlaceHolder1_cmbSearch' and (text() = '
	CollectorID
	Collector Name
	Collector Type

' or . = '
	CollectorID
	Collector Name
	Collector Type

')]</value>
      <webElementGuid>de34336b-c943-4a07-a3da-b012f7937de6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
