<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Collector List</name>
   <tag></tag>
   <elementGuidId>4ff3cfb3-7d11-42e7-ad58-3bfb77b6c6e5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_Menu1n25 > td > table.ctl00_Menu1_6 > tbody > tr > td > a.ctl00_Menu1_1.ctl00_Menu1_5</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='ctl00_Menu1n25']/td/table/tbody/tr/td/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>43ed8237-af3f-44e6-9823-5aa9f0da5b87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ctl00_Menu1_1 ctl00_Menu1_5</value>
      <webElementGuid>3ca4ba36-4fe8-4e8e-821a-1cfa8f979701</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>fCollectorList.aspx</value>
      <webElementGuid>0693e542-4ab9-4e14-820c-480cd4b148e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Collector List</value>
      <webElementGuid>fb3de82b-e23c-4edb-bcfc-12e54154e9a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_Menu1n25&quot;)/td[1]/table[@class=&quot;ctl00_Menu1_6&quot;]/tbody[1]/tr[1]/td[1]/a[@class=&quot;ctl00_Menu1_1 ctl00_Menu1_5&quot;]</value>
      <webElementGuid>b86e19d2-98ba-41a6-b5f1-30d549d0443c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='ctl00_Menu1n25']/td/table/tbody/tr/td/a</value>
      <webElementGuid>6ee53ab0-59e5-44fe-b081-2236c637110e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Collector List')]</value>
      <webElementGuid>258f02d8-057e-4cad-a026-2ed84ea23032</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='User List'])[1]/following::a[1]</value>
      <webElementGuid>2b11bb6b-ef7c-4f75-a505-c60362fe0ec3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[1]/following::a[2]</value>
      <webElementGuid>8facc9fc-36f3-4cb4-9cb7-2d8feb0ae756</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Role Menu'])[1]/preceding::a[1]</value>
      <webElementGuid>abe22b97-7429-491a-82f0-db5631714bb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Update Status WO'])[1]/preceding::a[2]</value>
      <webElementGuid>edf6b5b1-1fd8-473c-bd25-669c53c10b47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Collector List']/parent::*</value>
      <webElementGuid>34b74191-e135-41d8-b94f-de56dedf2a81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'fCollectorList.aspx')]</value>
      <webElementGuid>66048652-a159-4ff0-b56a-a0b9a44f5a6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/table/tbody/tr[4]/td/table/tbody/tr/td/a</value>
      <webElementGuid>d689e5a2-e659-42fb-9634-f68b28f57162</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'fCollectorList.aspx' and (text() = 'Collector List' or . = 'Collector List')]</value>
      <webElementGuid>70ffe782-8201-4c63-b9c4-0f11f7b849fb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
