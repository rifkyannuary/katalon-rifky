<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_region</name>
   <tag></tag>
   <elementGuidId>60e948c9-67a4-4d15-9f1b-07bc8d974f5a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ctl00_ContentPlaceHolder1_dlRegion</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>78f2212b-1a2e-4e8c-93a4-c90875070e07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$ContentPlaceHolder1$dlRegion</value>
      <webElementGuid>b5cfcd68-3767-4f8a-8560-d087c2398600</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ctl00_ContentPlaceHolder1_dlRegion</value>
      <webElementGuid>76b6d28d-962c-4da2-a5fc-318f16b6bb4e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR

</value>
      <webElementGuid>d8f8a6aa-a985-429e-ad91-65490f901747</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_dlRegion&quot;)</value>
      <webElementGuid>c6ec35f1-7cdb-4a23-81d5-cb81170459d9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='ctl00_ContentPlaceHolder1_dlRegion']</value>
      <webElementGuid>1b4103a8-cb84-44c1-b4f3-98566e8752aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/table/tbody/tr[8]/td/div/table/tbody/tr[2]/td[2]/select</value>
      <webElementGuid>a851ea32-5360-4972-a387-30f65dff8609</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Region'])[1]/following::select[1]</value>
      <webElementGuid>e523c177-97ab-43b3-beb1-33ff21d21344</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Performance WO'])[2]/following::select[1]</value>
      <webElementGuid>4e3c5ac8-a86d-4a48-b2e5-c6c12a5fc2d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Product'])[1]/preceding::select[1]</value>
      <webElementGuid>b975dfd1-3774-4a8a-94c4-69f54f4a9d8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Type'])[1]/preceding::select[2]</value>
      <webElementGuid>00ee9432-fe9b-49c6-b6b7-93d477e0975f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>97c93f49-8c6c-412a-b889-da8b653d5bfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$ContentPlaceHolder1$dlRegion' and @id = 'ctl00_ContentPlaceHolder1_dlRegion' and (text() = '
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR

' or . = '
	JABODETABEK
	JAWA BARAT
	JAWA TENGAH
	JAWA TIMUR
	SUMATERA BAG. UTARA
	SUMATERA BAG. SELATAN
	KALIMANTAN
	SULAWESI
	INTIM
	SULAWESI SELATAN
	SULAWESI UTARA
	JABODETABEK BARAT
	JABODETABEK DKI
	JABODETABEK TIMUR
	JAWA BARAT 2
	JAWA BARAT 3
	SUMATERA
	KALIMANTAN BAG SELTENG
	KALIMANTAN BAG TIMBAR

')]</value>
      <webElementGuid>1f2265ee-c67b-42b2-80a4-15ab6d3b9f1e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
